#!/usr/bin/env bash
set -e
echo "=== DNS ==="
dig +noall +answer newsletter.turczynski.pl
dig +noall +answer _dmarc.newsletter.turczynski.pl txt
dig +noall +answer _smtp._tls.newsletter.turczynski.pl txt
dig +noall +answer _mta-sts.newsletter.turczynski.pl txt
echo
echo "=== HEADERS ==="
curl -s -I https://newsletter.turczynski.pl | grep -Ei "strict|content|referrer|permissions|x-|cache-control|policy"
