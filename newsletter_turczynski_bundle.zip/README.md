# newsletter.turczynski.pl — Hardening & Integration Bundle

This package contains ready-to-use Cloudflare configuration and helper files to harden and instrument
your Substack-backed subdomain, while keeping changes reversible and safe.

## Contents
- `rules/transform_rule.json` — Cloudflare Transform Rule to add/remove headers (import via Dashboard).
- `worker/newsletter-proxy.js` — Optional Worker that proxies Substack and sets headers.
- `dns/bind-snippets.txt` — BIND-format DNS records for DMARC, TLS-RPT, MTA-STS, DKIM (example).
- `mta-sts/.well-known/mta-sts.txt` — Starter MTA-STS policy file (testing mode).
- `verification/check_newsletter.sh` — One-shot script to verify DNS and headers.

## Option A — Transform Rule (no origin change)
1. Cloudflare Dashboard → Rules → Transform Rules → Response Header Modification → **Import JSON**.
2. Use `rules/transform_rule.json`.
3. This sets strict privacy/security headers and a conservative **CSP-Report-Only** (won't break Substack).
4. Verify:
   ```bash
   bash verification/check_newsletter.sh
   ```
5. If no CSP violations of concern appear, you may copy the CSP from `-Report-Only` into a full `Content-Security-Policy` header.

## Option B — Worker Proxy (more control)
1. Edit `worker/newsletter-proxy.js` and set `originBase` to your exact Substack domain.
2. Deploy with Wrangler:
   ```bash
   wrangler publish worker/newsletter-proxy.js --name newsletter-turczynski --route "newsletter.turczynski.pl/*"
   ```
3. Verify with `verification/check_newsletter.sh`.

## DNS Enhancements (subdomain-only)
- Add the records from `dns/bind-snippets.txt` in your DNS provider (Cloudflare DNS → Records).
- Host the MTA-STS policy at `https://mta-sts.newsletter.turczynski.pl/.well-known/mta-sts.txt`.
  Keep `mode: testing` initially, and switch to `enforce` after a few days of clean TLS-RPT.

## Safety notes
- Keep CSP in **Report-Only** until you’re confident nothing is blocked by Substack’s runtime.
- Avoid setting `X-Frame-Options` since Substack already uses `frame-ancestors` in CSP.
- The Transform Rule’s HSTS includes `includeSubDomains; preload` for safety with the apex policy.
- If you later remove the Worker, delete the route to avoid double-processing.

## Validation checklist
- `curl -I https://newsletter.turczynski.pl | grep -Ei "strict|referrer|permissions|x-content|cache-control|policy"`
- `dig +noall +answer _dmarc.newsletter.turczynski.pl txt`
- `dig +noall +answer _smtp._tls.newsletter.turczynski.pl txt`
- `dig +noall +answer _mta-sts.newsletter.turczynski.pl txt`

---
Produced for turczynski.pl (November 2025).
