export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const originBase = "https://bartturczynski.substack.com"; // change if needed
    const originURL = originBase + url.pathname + url.search;
    const resp = await fetch(originURL, request);
    const headers = new Headers(resp.headers);
    ["x-powered-by","x-served-by","x-service","x-deploy"].forEach(h=>headers.delete(h));
    headers.set("Referrer-Policy","strict-origin-when-cross-origin");
    headers.set("Permissions-Policy","accelerometer=(), autoplay=(), camera=(), clipboard-read=(), clipboard-write=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=(), fullscreen=()");
    headers.set("X-Content-Type-Options","nosniff");
    headers.set("Cache-Control","public, max-age=0, must-revalidate");
    headers.set("Strict-Transport-Security","max-age=31536000; includeSubDomains; preload");
    headers.set("Content-Security-Policy-Report-Only","default-src 'self' https:; img-src 'self' https: data:; object-src 'none'; base-uri 'self'; form-action 'self' https:; frame-ancestors 'self' https://*.substack.com https://substack.com; upgrade-insecure-requests");
    return new Response(resp.body, { status: resp.status, statusText: resp.statusText, headers });
  }
}